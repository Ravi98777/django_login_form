from app.models import contact 
from django import forms

class ContactForm(forms.ModelForm):
    class Meta:
        model = contact
        fields = ['first_name', 'last_name', 'email', 'content']