from django.shortcuts import render
from app.forms import ContactForm

def index(request):
    # Instantiate the form (empty, for GET request)
    form = ContactForm()
    
    # Render the template and pass the form in context
    return render(request, 'index.html', {'form': form})
